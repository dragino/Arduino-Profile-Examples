sokit.lan is language file, if rename or delete it, then use default english UI

F1 for more help or go http://code.google.com/p/sokit/ for sourcecode